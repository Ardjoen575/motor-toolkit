package com.inductool.motorkit

import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Standard public-domain induction-motor engineering formulas.
 * Sources: general AC machine theory (Ns = 120f/P), IEC/NEC style ampacity
 * and motor-protection sizing rules of thumb. All results are estimates for
 * planning purposes only and should be verified against the applicable
 * local electrical code and manufacturer nameplate data before installation.
 */
object Calculators {

    // ---------- 1. Speed & Slip ----------
    data class SpeedSlipResult(
        val synchronousSpeedRpm: Double,
        val slip: Double,
        val slipPercent: Double
    )

    fun speedAndSlip(frequencyHz: Double, poles: Int, rotorSpeedRpm: Double): SpeedSlipResult {
        val ns = 120.0 * frequencyHz / poles
        val slip = if (ns == 0.0) 0.0 else (ns - rotorSpeedRpm) / ns
        return SpeedSlipResult(ns, slip, slip * 100.0)
    }

    // ---------- 2. Torque ----------
    data class TorqueResult(
        val ratedTorqueNm: Double,
        val startingTorqueNm: Double,
        val breakdownTorqueNm: Double
    )

    fun torque(powerKw: Double, rotorSpeedRpm: Double, startingTorqueMultiple: Double, breakdownTorqueMultiple: Double): TorqueResult {
        val ratedNm = if (rotorSpeedRpm == 0.0) 0.0 else (9550.0 * powerKw) / rotorSpeedRpm
        return TorqueResult(
            ratedTorqueNm = ratedNm,
            startingTorqueNm = ratedNm * startingTorqueMultiple,
            breakdownTorqueNm = ratedNm * breakdownTorqueMultiple
        )
    }

    // ---------- 3. Electrical Power ----------
    data class PowerResult(
        val currentA: Double,
        val realPowerKw: Double,
        val apparentPowerKva: Double,
        val reactivePowerKvar: Double
    )

    fun threePhasePower(voltageLL: Double, currentA: Double, powerFactor: Double, efficiency: Double): PowerResult {
        val apparentVa = sqrt(3.0) * voltageLL * currentA
        val realW = apparentVa * powerFactor * efficiency
        val phiFromPf = acos(powerFactor.coerceIn(-1.0, 1.0))
        val reactiveVar = apparentVa * kotlin.math.sin(phiFromPf)
        return PowerResult(currentA, realW / 1000.0, apparentVa / 1000.0, reactiveVar / 1000.0)
    }

    fun singlePhasePower(voltage: Double, currentA: Double, powerFactor: Double, efficiency: Double): PowerResult {
        val apparentVa = voltage * currentA
        val realW = apparentVa * powerFactor * efficiency
        val phiFromPf = acos(powerFactor.coerceIn(-1.0, 1.0))
        val reactiveVar = apparentVa * kotlin.math.sin(phiFromPf)
        return PowerResult(currentA, realW / 1000.0, apparentVa / 1000.0, reactiveVar / 1000.0)
    }

    fun currentFromPower(powerKw: Double, voltage: Double, powerFactor: Double, efficiency: Double, threePhase: Boolean): Double {
        val realW = powerKw * 1000.0
        return if (threePhase) {
            realW / (sqrt(3.0) * voltage * powerFactor * efficiency)
        } else {
            realW / (voltage * powerFactor * efficiency)
        }
    }

    // ---------- 4. Power Factor Correction ----------
    data class PfCorrectionResult(
        val requiredKvar: Double,
        val capacitanceMicroFarad: Double
    )

    fun pfCorrection(
        realPowerKw: Double,
        existingPf: Double,
        targetPf: Double,
        voltage: Double,
        frequencyHz: Double,
        threePhase: Boolean
    ): PfCorrectionResult {
        val tan1 = tan(acos(existingPf.coerceIn(0.01, 1.0)))
        val tan2 = tan(acos(targetPf.coerceIn(0.01, 1.0)))
        val qcKvar = realPowerKw * (tan1 - tan2)
        val qcVar = qcKvar * 1000.0

        // Capacitance per phase of a delta-connected bank: Qc_total = 3 * 2*pi*f*C*V^2
        // For single-phase, the full reactive power is supplied by one capacitor across the line.
        val capFarad = if (threePhase) {
            qcVar / (3.0 * 2.0 * PI * frequencyHz * voltage * voltage)
        } else {
            qcVar / (2.0 * PI * frequencyHz * voltage * voltage)
        }

        return PfCorrectionResult(qcKvar, capFarad * 1_000_000.0)
    }

    // ---------- 5. Energy & Cost ----------
    data class EnergyCostResult(
        val dailyKwh: Double,
        val monthlyKwh: Double,
        val annualKwh: Double,
        val dailyCost: Double,
        val monthlyCost: Double,
        val annualCost: Double
    )

    fun energyAndCost(powerKw: Double, hoursPerDay: Double, daysPerMonth: Double, ratePerKwh: Double): EnergyCostResult {
        val dailyKwh = powerKw * hoursPerDay
        val monthlyKwh = dailyKwh * daysPerMonth
        val annualKwh = monthlyKwh * 12.0
        return EnergyCostResult(
            dailyKwh, monthlyKwh, annualKwh,
            dailyKwh * ratePerKwh, monthlyKwh * ratePerKwh, annualKwh * ratePerKwh
        )
    }

    // ---------- 6. Cable Sizing ----------
    // Simplified copper/PVC 70C ampacity reference table (approximate, free-air / conduit, illustrative).
    // Cross-section (mm^2) to base ampacity (A). Always verify against local code tables.
    val cableAmpacityTable: List<Pair<Double, Double>> = listOf(
        1.5 to 17.5, 2.5 to 24.0, 4.0 to 32.0, 6.0 to 41.0, 10.0 to 57.0,
        16.0 to 76.0, 25.0 to 101.0, 35.0 to 125.0, 50.0 to 151.0,
        70.0 to 192.0, 95.0 to 232.0, 120.0 to 269.0, 150.0 to 300.0,
        185.0 to 341.0, 240.0 to 400.0
    )

    data class CableResult(
        val designCurrentA: Double,
        val adjustedCurrentA: Double,
        val recommendedCableMm2: Double,
        val recommendedCableAmpacity: Double
    )

    fun cableSize(
        flcA: Double,
        ambientDeratingFactor: Double,
        groupingDeratingFactor: Double,
        safetyMultiplier: Double = 1.25
    ): CableResult {
        val designCurrent = flcA * safetyMultiplier
        val combinedDerating = (ambientDeratingFactor * groupingDeratingFactor).coerceAtLeast(0.1)
        val adjustedCurrent = designCurrent / combinedDerating
        val chosen = cableAmpacityTable.firstOrNull { it.second >= adjustedCurrent }
            ?: cableAmpacityTable.last()
        return CableResult(designCurrent, adjustedCurrent, chosen.first, chosen.second)
    }

    // ---------- 7. Motor Protection Sizing ----------
    data class ProtectionResult(
        val overloadMinA: Double,
        val overloadMaxA: Double,
        val breakerRatingA: Double,
        val startingCurrentEstimateA: Double
    )

    fun protectionSizing(flcA: Double, startingCurrentMultiple: Double): ProtectionResult {
        // Thermal overload relay typically set 1.00-1.25x FLC
        val overloadMin = flcA * 1.00
        val overloadMax = flcA * 1.25
        val startingCurrent = flcA * startingCurrentMultiple
        // Simplified instantaneous/magnetic breaker sizing guidance: ~2.5x FLC for standard,
        // rounded up conceptually; real selection must follow local code tables & breaker curves.
        val breakerRating = flcA * 2.5
        return ProtectionResult(overloadMin, overloadMax, breakerRating, startingCurrent)
    }

    // ---------- 8. Winding Scheme (double-layer, 3-phase, 60° phase belt) ----------
    data class SlotAssignment(val slotIndex: Int, val phase: String, val direction: Int) // direction +1 / -1
    data class WindingSchemeResult(
        val slotsPerPole: Double,
        val slotsPerPolePerPhase: Double,
        val isIntegerSlot: Boolean,
        val electricalDegreesPerSlot: Double,
        val fullPitchSlots: Int,
        val recommendedChordedPitchSlots: Int,
        val pitchFactorKp: Double,
        val distributionFactorKd: Double,
        val windingFactorKw: Double,
        val slotTable: List<SlotAssignment>
    )

    fun windingScheme(slots: Int, poles: Int, phases: Int = 3, coilPitchSlots: Int? = null): WindingSchemeResult {
        val slotsPerPole = slots.toDouble() / poles
        val q = slots.toDouble() / (poles * phases)
        val isInteger = kotlin.math.abs(q - q.roundToInt()) < 1e-6
        val elecDegPerSlot = 180.0 * poles / slots

        val fullPitch = slotsPerPole.roundToInt()
        val chorded = coilPitchSlots ?: (fullPitch * 5.0 / 6.0).roundToInt().coerceAtLeast(1)

        // Pitch factor Kp = sin(pitch_ratio * 90 deg)
        val pitchRatio = chorded.toDouble() / fullPitch.toDouble()
        val kp = sin(Math.toRadians(pitchRatio * 90.0))

        // Distribution factor Kd = sin(q * slotAngle/2) / (q * sin(slotAngle/2))
        val slotAngleRad = Math.toRadians(elecDegPerSlot)
        val qForKd = q.coerceAtLeast(0.01)
        val kd = sin(qForKd * slotAngleRad / 2.0) / (qForKd * sin(slotAngleRad / 2.0))

        val kw = kp * kd

        val sectorPhase = arrayOf("A", "C", "B", "A", "C", "B")
        val sectorDir = arrayOf(1, -1, 1, -1, 1, -1)

        val table = (0 until slots).map { i ->
            val angle = (i * elecDegPerSlot).mod(360.0)
            val sector = floor(angle / 60.0).toInt().coerceIn(0, 5)
            SlotAssignment(i, sectorPhase[sector], sectorDir[sector])
        }

        return WindingSchemeResult(
            slotsPerPole, q, isInteger, elecDegPerSlot,
            fullPitch, chorded, kp, kd, kw, table
        )
    }

    // ---------- 9. Turns Calculation (proportional rewind + flux-based design) ----------
    data class ProportionalRewindResult(
        val newTurnsPerCoil: Double,
        val newCurrentA: Double,
        val newWireCsaMm2: Double,
        val newWireDiameterMm: Double
    )

    fun proportionalRewind(
        oldTurnsPerCoil: Double,
        oldVoltage: Double,
        newVoltage: Double,
        oldCurrentA: Double,
        oldWireDiameterMm: Double
    ): ProportionalRewindResult {
        if (oldVoltage <= 0.0) return ProportionalRewindResult(0.0, 0.0, 0.0, 0.0)
        val ratio = newVoltage / oldVoltage
        val newTurns = oldTurnsPerCoil * ratio
        val newCurrent = oldCurrentA / ratio
        val oldCsa = PI * (oldWireDiameterMm / 2.0).let { it * it }
        val newCsa = oldCsa / ratio // keep ~constant current density
        val newDiameter = 2.0 * sqrt(newCsa / PI)
        return ProportionalRewindResult(newTurns, newCurrent, newCsa, newDiameter)
    }

    data class FluxDesignResult(
        val fluxPerPoleWb: Double,
        val turnsPerPhase: Double,
        val turnsPerCoil: Double
    )

    fun fluxBasedTurns(
        phaseVoltage: Double,
        frequencyHz: Double,
        boreDiameterMm: Double,
        stackLengthMm: Double,
        poles: Int,
        fluxDensityTesla: Double,
        windingFactor: Double,
        coilsPerPhase: Int,
        parallelPaths: Int
    ): FluxDesignResult {
        val poleAreaM2 = (PI * (boreDiameterMm / 1000.0) * (stackLengthMm / 1000.0)) / poles
        val fluxPerPole = fluxDensityTesla * poleAreaM2
        val denom = 4.44 * frequencyHz * fluxPerPole * windingFactor.coerceAtLeast(0.01)
        val turnsPerPhase = if (denom == 0.0) 0.0 else phaseVoltage / denom
        val turnsPerCoil = if (coilsPerPhase == 0) 0.0 else (turnsPerPhase * parallelPaths) / coilsPerPhase
        return FluxDesignResult(fluxPerPole, turnsPerPhase, turnsPerCoil)
    }

    // ---------- 10. Coil / Copper Weight & Wire ----------
    // Common magnet-wire sizes (AWG -> bare diameter mm), reference values.
    val awgToMm: List<Pair<Int, Double>> = listOf(
        10 to 2.588, 12 to 2.053, 14 to 1.628, 16 to 1.291, 18 to 1.024,
        19 to 0.912, 20 to 0.812, 21 to 0.723, 22 to 0.644, 23 to 0.573,
        24 to 0.511, 25 to 0.455, 26 to 0.405, 27 to 0.361, 28 to 0.321,
        29 to 0.286, 30 to 0.255, 31 to 0.227, 32 to 0.202, 34 to 0.160,
        36 to 0.127, 38 to 0.101, 40 to 0.080
    )

    const val copperDensityGPerCm3 = 8.96
    const val copperResistivityOhmM = 1.68e-8

    data class CoilWeightResult(
        val wireCsaMm2: Double,
        val totalLengthM: Double,
        val totalWeightKg: Double,
        val estimatedResistanceOhm: Double
    )

    fun coilWeight(
        wireDiameterMm: Double,
        turnsPerCoil: Double,
        numberOfCoils: Double,
        meanLengthPerTurnMm: Double
    ): CoilWeightResult {
        val csaMm2 = PI * (wireDiameterMm / 2.0).let { it * it }
        val totalTurns = turnsPerCoil * numberOfCoils
        val totalLengthMm = meanLengthPerTurnMm * totalTurns
        val totalLengthM = totalLengthMm / 1000.0
        val volumeMm3 = totalLengthMm * csaMm2
        val volumeCm3 = volumeMm3 / 1000.0
        val weightKg = (volumeCm3 * copperDensityGPerCm3) / 1000.0
        val csaM2 = csaMm2 * 1e-6
        val resistance = if (csaM2 == 0.0) 0.0 else copperResistivityOhmM * totalLengthM / csaM2
        return CoilWeightResult(csaMm2, totalLengthM, weightKg, resistance)
    }

    // Rule-of-thumb mean-length-per-turn estimate (mm) from core geometry.
    // MLT ≈ 2 × stack length + 2.5 × pole pitch (common rewind-shop approximation).
    fun estimateMlt(stackLengthMm: Double, polePitchMm: Double): Double {
        return 2.0 * stackLengthMm + 2.5 * polePitchMm
    }
}
