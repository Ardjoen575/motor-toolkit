package com.inductool.motorkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.inductool.motorkit.screens.*
import com.inductool.motorkit.ui.theme.MotorKitTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MotorKitTheme {
                AppRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "home"
    val currentTitle = toolEntries.firstOrNull { it.route == currentRoute }?.title ?: "Induction Motor Toolkit"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(currentTitle) },
                navigationIcon = {
                    if (currentRoute != "home") {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen { route -> navController.navigate(route) } }
            composable("speed_slip") { SpeedSlipScreen() }
            composable("torque") { TorqueScreen() }
            composable("power") { PowerScreen() }
            composable("pf_correction") { PfCorrectionScreen() }
            composable("energy_cost") { EnergyCostScreen() }
            composable("cable_sizing") { CableSizingScreen() }
            composable("protection") { ProtectionScreen() }
            composable("winding_scheme") { WindingSchemeScreen() }
            composable("turns_rewind") { TurnsRewindScreen() }
            composable("coil_weight") { CoilWeightScreen() }
        }
    }
}
