package com.inductool.motorkit.screens

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import com.inductool.motorkit.Calculators

@Composable
fun CableSizingScreen() {
    var flc by remember { mutableStateOf("15") }
    var ambientDerating by remember { mutableStateOf("0.94") }
    var groupingDerating by remember { mutableStateOf("0.80") }
    var safetyMultiplier by remember { mutableStateOf("1.25") }

    val result = remember(flc, ambientDerating, groupingDerating, safetyMultiplier) {
        Calculators.cableSize(
            flc.toDoubleOrZero(), ambientDerating.toDoubleOrZero(),
            groupingDerating.toDoubleOrZero(), safetyMultiplier.toDoubleOrZero().let { if (it == 0.0) 1.25 else it }
        )
    }

    ScreenScaffold(
        title = "Cable Sizing",
        helpText = "Suggested copper conductor cross-section from full-load current, with ambient and grouping derating. Always verify against your local wiring code (IEC 60364 / NEC) and manufacturer cable data."
    ) {
        NumberField("Full Load Current (FLC)", flc, "A") { flc = it }
        NumberField("Ambient Temperature Derating", ambientDerating) { ambientDerating = it }
        NumberField("Grouping Derating", groupingDerating) { groupingDerating = it }
        NumberField("Safety Multiplier", safetyMultiplier) { safetyMultiplier = it }

        ResultCard(
            "Results",
            listOf(
                "Design Current" to "${fmt(result.designCurrentA)} A",
                "Derated (Adjusted) Current" to "${fmt(result.adjustedCurrentA)} A",
                "Recommended Cable" to "${fmt(result.recommendedCableMm2, 1)} mm²",
                "Cable Rated Ampacity" to "${fmt(result.recommendedCableAmpacity)} A"
            )
        )

        Text(
            "Table used is an illustrative copper/PVC 70°C reference — not a substitute for the official ampacity tables in your jurisdiction.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
