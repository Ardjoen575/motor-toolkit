package com.inductool.motorkit.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.inductool.motorkit.Calculators

@Composable
fun CoilWeightScreen() {
    var wireDia by remember { mutableStateOf("1.0") }
    var turnsPerCoil by remember { mutableStateOf("120") }
    var numberOfCoils by remember { mutableStateOf("36") }
    var stackLength by remember { mutableStateOf("100") }
    var polePitchMm by remember { mutableStateOf("95") }
    var mltOverride by remember { mutableStateOf("") }
    var awgExpanded by remember { mutableStateOf(false) }

    val estimatedMlt = remember(stackLength, polePitchMm) {
        Calculators.estimateMlt(stackLength.toDoubleOrZero(), polePitchMm.toDoubleOrZero())
    }
    val mlt = mltOverride.toDoubleOrNull() ?: estimatedMlt

    val result = remember(wireDia, turnsPerCoil, numberOfCoils, mlt) {
        Calculators.coilWeight(
            wireDia.toDoubleOrZero(), turnsPerCoil.toDoubleOrZero(),
            numberOfCoils.toDoubleOrZero(), mlt
        )
    }

    ScreenScaffold(
        title = "Coil Weight & Wire",
        helpText = "Estimated copper wire length, weight, and DC resistance for the full winding, from wire gauge, turns, and coil count."
    ) {
        Box(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            OutlinedTextField(
                value = wireDia,
                onValueChange = { wireDia = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Wire Diameter (bare)") },
                suffix = { Text("mm") },
                trailingIcon = {
                    TextButton(onClick = { awgExpanded = true }) { Text("AWG") }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            DropdownMenu(expanded = awgExpanded, onDismissRequest = { awgExpanded = false }) {
                Calculators.awgToMm.forEach { (awg, mm) ->
                    DropdownMenuItem(
                        text = { Text("AWG $awg  —  $mm mm") },
                        onClick = {
                            wireDia = mm.toString()
                            awgExpanded = false
                        }
                    )
                }
            }
        }

        NumberField("Turns per Coil", turnsPerCoil) { turnsPerCoil = it }
        NumberField("Number of Coils (total)", numberOfCoils) { numberOfCoils = it }
        NumberField("Core Stack Length", stackLength, "mm") { stackLength = it }
        NumberField("Pole Pitch", polePitchMm, "mm") { polePitchMm = it }
        NumberField("Mean Length/Turn Override (optional)", mltOverride, "mm") { mltOverride = it }

        Text(
            "Estimated MLT in use: ${fmt(mlt, 1)} mm",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        ResultCard(
            "Copper Estimate",
            listOf(
                "Wire Cross-Section" to "${fmt(result.wireCsaMm2, 4)} mm²",
                "Total Wire Length" to "${fmt(result.totalLengthM, 1)} m",
                "Total Copper Weight" to "${fmt(result.totalWeightKg, 3)} kg",
                "Estimated DC Resistance" to "${fmt(result.estimatedResistanceOhm, 4)} Ω"
            )
        )
    }
}
