package com.inductool.motorkit.screens

import androidx.compose.runtime.*
import com.inductool.motorkit.Calculators

@Composable
fun EnergyCostScreen() {
    var powerKw by remember { mutableStateOf("7.5") }
    var hoursPerDay by remember { mutableStateOf("8") }
    var daysPerMonth by remember { mutableStateOf("26") }
    var rate by remember { mutableStateOf("0.15") }

    val result = remember(powerKw, hoursPerDay, daysPerMonth, rate) {
        Calculators.energyAndCost(
            powerKw.toDoubleOrZero(), hoursPerDay.toDoubleOrZero(),
            daysPerMonth.toDoubleOrZero(), rate.toDoubleOrZero()
        )
    }

    ScreenScaffold(
        title = "Energy & Cost",
        helpText = "Estimated energy consumption and running cost based on motor load and duty cycle."
    ) {
        NumberField("Motor Real Power", powerKw, "kW") { powerKw = it }
        NumberField("Operating Hours / Day", hoursPerDay, "h") { hoursPerDay = it }
        NumberField("Operating Days / Month", daysPerMonth, "days") { daysPerMonth = it }
        NumberField("Electricity Rate", rate, "/kWh") { rate = it }

        ResultCard(
            "Energy",
            listOf(
                "Daily" to "${fmt(result.dailyKwh)} kWh",
                "Monthly" to "${fmt(result.monthlyKwh)} kWh",
                "Annual" to "${fmt(result.annualKwh)} kWh"
            )
        )
        ResultCard(
            "Cost",
            listOf(
                "Daily" to fmt(result.dailyCost),
                "Monthly" to fmt(result.monthlyCost),
                "Annual" to fmt(result.annualCost)
            )
        )
    }
}
