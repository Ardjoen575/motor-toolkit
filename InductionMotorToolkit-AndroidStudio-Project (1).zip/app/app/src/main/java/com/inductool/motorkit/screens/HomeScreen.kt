package com.inductool.motorkit.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class ToolEntry(val route: String, val title: String, val subtitle: String, val icon: ImageVector)

val toolEntries = listOf(
    ToolEntry("speed_slip", "Speed & Slip", "Sync speed, slip %", Icons.Default.Speed),
    ToolEntry("torque", "Torque", "Rated / start / breakdown", Icons.Default.Settings),
    ToolEntry("power", "Electrical Power", "kW / kVA / kVAR", Icons.Default.Bolt),
    ToolEntry("pf_correction", "PF Correction", "Capacitor sizing", Icons.Default.BatteryChargingFull),
    ToolEntry("energy_cost", "Energy & Cost", "Running cost estimate", Icons.Default.AttachMoney),
    ToolEntry("cable_sizing", "Cable Sizing", "Conductor cross-section", Icons.Default.Cable),
    ToolEntry("protection", "Motor Protection", "Overload & breaker", Icons.Default.Shield),
    ToolEntry("winding_scheme", "Winding Scheme", "Pole pitch, slot table", Icons.Default.GridView),
    ToolEntry("turns_rewind", "Turns & Rewind", "Proportional / flux design", Icons.Default.Autorenew),
    ToolEntry("coil_weight", "Coil Weight & Wire", "Copper length & weight", Icons.Default.Scale),
)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp)) {
            Text("Induction Motor Toolkit", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(
                "Sizing, protection & rewinding calculators for asynchronous motors",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(toolEntries) { tool ->
                ToolCard(tool) { onNavigate(tool.route) }
            }
        }
    }
}

@Composable
private fun ToolCard(tool: ToolEntry, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(tool.icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.height(10.dp))
            Text(tool.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(tool.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
