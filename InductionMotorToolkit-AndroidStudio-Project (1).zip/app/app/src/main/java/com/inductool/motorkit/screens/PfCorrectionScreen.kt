package com.inductool.motorkit.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.inductool.motorkit.Calculators

@Composable
fun PfCorrectionScreen() {
    var threePhase by remember { mutableStateOf(true) }
    var powerKw by remember { mutableStateOf("7.5") }
    var existingPf by remember { mutableStateOf("0.75") }
    var targetPf by remember { mutableStateOf("0.95") }
    var voltage by remember { mutableStateOf("400") }
    var freq by remember { mutableStateOf("50") }

    val result = remember(threePhase, powerKw, existingPf, targetPf, voltage, freq) {
        Calculators.pfCorrection(
            powerKw.toDoubleOrZero(),
            existingPf.toDoubleOrZero(),
            targetPf.toDoubleOrZero(),
            voltage.toDoubleOrZero(),
            freq.toDoubleOrZero(),
            threePhase
        )
    }

    ScreenScaffold(
        title = "PF Correction",
        helpText = "Required capacitor bank (kVAR and µF per phase) to raise power factor from existing to target."
    ) {
        Row {
            FilterChip(selected = threePhase, onClick = { threePhase = true }, label = { Text("3-Phase") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = !threePhase, onClick = { threePhase = false }, label = { Text("1-Phase") })
        }
        Spacer(Modifier.height(8.dp))
        NumberField("Real Power", powerKw, "kW") { powerKw = it }
        NumberField("Existing Power Factor", existingPf) { existingPf = it }
        NumberField("Target Power Factor", targetPf) { targetPf = it }
        NumberField(if (threePhase) "Line Voltage" else "Voltage", voltage, "V") { voltage = it }
        NumberField("Frequency", freq, "Hz") { freq = it }

        ResultCard(
            "Results",
            listOf(
                "Required Capacitor Bank" to "${fmt(result.requiredKvar)} kVAR",
                "Capacitance per Phase" to "${fmt(result.capacitanceMicroFarad)} µF"
            )
        )
    }
}
