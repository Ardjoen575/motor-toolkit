package com.inductool.motorkit.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.inductool.motorkit.Calculators

@Composable
fun PowerScreen() {
    var threePhase by remember { mutableStateOf(true) }
    var voltage by remember { mutableStateOf("400") }
    var current by remember { mutableStateOf("15") }
    var pf by remember { mutableStateOf("0.85") }
    var efficiency by remember { mutableStateOf("0.90") }

    val result = remember(threePhase, voltage, current, pf, efficiency) {
        val v = voltage.toDoubleOrZero(); val i = current.toDoubleOrZero()
        val pfv = pf.toDoubleOrZero(); val eff = efficiency.toDoubleOrZero()
        if (threePhase) Calculators.threePhasePower(v, i, pfv, eff)
        else Calculators.singlePhasePower(v, i, pfv, eff)
    }

    ScreenScaffold(
        title = "Electrical Power",
        helpText = "Real, apparent, and reactive power from voltage, current, power factor, and efficiency."
    ) {
        Row {
            FilterChip(selected = threePhase, onClick = { threePhase = true }, label = { Text("3-Phase") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = !threePhase, onClick = { threePhase = false }, label = { Text("1-Phase") })
        }
        Spacer(Modifier.height(8.dp))
        NumberField(if (threePhase) "Line Voltage" else "Voltage", voltage, "V") { voltage = it }
        NumberField("Current", current, "A") { current = it }
        NumberField("Power Factor", pf) { pf = it }
        NumberField("Efficiency", efficiency) { efficiency = it }

        ResultCard(
            "Results",
            listOf(
                "Real Power" to "${fmt(result.realPowerKw)} kW",
                "Apparent Power" to "${fmt(result.apparentPowerKva)} kVA",
                "Reactive Power" to "${fmt(result.reactivePowerKvar)} kVAR"
            )
        )
    }
}
