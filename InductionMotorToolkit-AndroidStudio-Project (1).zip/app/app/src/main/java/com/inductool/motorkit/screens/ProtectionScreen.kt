package com.inductool.motorkit.screens

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import com.inductool.motorkit.Calculators

@Composable
fun ProtectionScreen() {
    var flc by remember { mutableStateOf("15") }
    var startMultiple by remember { mutableStateOf("6.5") }

    val result = remember(flc, startMultiple) {
        Calculators.protectionSizing(flc.toDoubleOrZero(), startMultiple.toDoubleOrZero())
    }

    ScreenScaffold(
        title = "Motor Protection",
        helpText = "Thermal overload relay range and indicative breaker/fuse rating from full-load current. Final selection must follow the breaker's trip curve and local code."
    ) {
        NumberField("Full Load Current (FLC)", flc, "A") { flc = it }
        NumberField("Starting Current Multiple", startMultiple, "× FLC") { startMultiple = it }

        ResultCard(
            "Results",
            listOf(
                "Overload Relay Range" to "${fmt(result.overloadMinA)} – ${fmt(result.overloadMaxA)} A",
                "Estimated Starting Current" to "${fmt(result.startingCurrentEstimateA)} A",
                "Indicative Breaker/Fuse Rating" to "${fmt(result.breakerRatingA)} A"
            )
        )

        Text(
            "Breaker rating shown is a simplified planning estimate (≈2.5× FLC). Real selection depends on breaker curve type (B/C/D/MCCB) and starting method — verify with a qualified electrician.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
