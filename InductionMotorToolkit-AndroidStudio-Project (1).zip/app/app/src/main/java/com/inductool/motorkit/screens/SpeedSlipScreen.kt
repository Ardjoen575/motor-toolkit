package com.inductool.motorkit.screens

import androidx.compose.runtime.*
import com.inductool.motorkit.Calculators

@Composable
fun SpeedSlipScreen() {
    var freq by remember { mutableStateOf("50") }
    var poles by remember { mutableStateOf("4") }
    var rotorRpm by remember { mutableStateOf("1440") }

    val result = remember(freq, poles, rotorRpm) {
        val p = poles.toIntOrNull()?.coerceAtLeast(2) ?: 4
        Calculators.speedAndSlip(freq.toDoubleOrZero(), p, rotorRpm.toDoubleOrZero())
    }

    ScreenScaffold(
        title = "Speed & Slip",
        helpText = "Synchronous speed and slip from supply frequency, pole count, and measured rotor speed."
    ) {
        NumberField("Supply Frequency", freq, "Hz") { freq = it }
        NumberField("Number of Poles", poles) { poles = it }
        NumberField("Rotor (nameplate) Speed", rotorRpm, "rpm") { rotorRpm = it }

        ResultCard(
            "Results",
            listOf(
                "Synchronous Speed" to "${fmt(result.synchronousSpeedRpm, 0)} rpm",
                "Slip" to fmt(result.slip, 4),
                "Slip %" to "${fmt(result.slipPercent)} %"
            )
        )
    }
}
