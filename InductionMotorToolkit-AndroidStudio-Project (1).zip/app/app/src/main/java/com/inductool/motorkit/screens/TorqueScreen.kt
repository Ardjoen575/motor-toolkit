package com.inductool.motorkit.screens

import androidx.compose.runtime.*
import com.inductool.motorkit.Calculators

@Composable
fun TorqueScreen() {
    var powerKw by remember { mutableStateOf("7.5") }
    var speedRpm by remember { mutableStateOf("1440") }
    var startMultiple by remember { mutableStateOf("2.2") }
    var breakdownMultiple by remember { mutableStateOf("2.8") }

    val result = remember(powerKw, speedRpm, startMultiple, breakdownMultiple) {
        Calculators.torque(
            powerKw.toDoubleOrZero(),
            speedRpm.toDoubleOrZero(),
            startMultiple.toDoubleOrZero(),
            breakdownMultiple.toDoubleOrZero()
        )
    }

    ScreenScaffold(
        title = "Torque",
        helpText = "Rated shaft torque, plus estimated starting and breakdown torque using typical nameplate multiples (edit as needed)."
    ) {
        NumberField("Rated Power", powerKw, "kW") { powerKw = it }
        NumberField("Rated Speed", speedRpm, "rpm") { speedRpm = it }
        NumberField("Starting Torque Multiple", startMultiple, "× rated") { startMultiple = it }
        NumberField("Breakdown Torque Multiple", breakdownMultiple, "× rated") { breakdownMultiple = it }

        ResultCard(
            "Results",
            listOf(
                "Rated Torque" to "${fmt(result.ratedTorqueNm)} N·m",
                "Starting Torque (est.)" to "${fmt(result.startingTorqueNm)} N·m",
                "Breakdown Torque (est.)" to "${fmt(result.breakdownTorqueNm)} N·m"
            )
        )
    }
}
