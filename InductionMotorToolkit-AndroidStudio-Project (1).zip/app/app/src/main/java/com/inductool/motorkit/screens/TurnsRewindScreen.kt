package com.inductool.motorkit.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.inductool.motorkit.Calculators

private enum class RewindMethod { PROPORTIONAL, FLUX_DESIGN }

@Composable
fun TurnsRewindScreen() {
    var method by remember { mutableStateOf(RewindMethod.PROPORTIONAL) }

    ScreenScaffold(
        title = "Turns & Rewind",
        helpText = "Calculate new coil turns either by scaling a known good winding to a new voltage, or by designing turns from scratch using core dimensions and flux."
    ) {
        Row {
            FilterChip(
                selected = method == RewindMethod.PROPORTIONAL,
                onClick = { method = RewindMethod.PROPORTIONAL },
                label = { Text("Proportional Rewind") }
            )
            Spacer(Modifier.width(8.dp))
            FilterChip(
                selected = method == RewindMethod.FLUX_DESIGN,
                onClick = { method = RewindMethod.FLUX_DESIGN },
                label = { Text("Design from Core") }
            )
        }
        Spacer(Modifier.height(12.dp))

        if (method == RewindMethod.PROPORTIONAL) {
            ProportionalSection()
        } else {
            FluxDesignSection()
        }
    }
}

@Composable
private fun ProportionalSection() {
    var oldTurns by remember { mutableStateOf("120") }
    var oldVoltage by remember { mutableStateOf("230") }
    var newVoltage by remember { mutableStateOf("400") }
    var oldCurrent by remember { mutableStateOf("14") }
    var oldWireDia by remember { mutableStateOf("1.0") }

    val result = remember(oldTurns, oldVoltage, newVoltage, oldCurrent, oldWireDia) {
        Calculators.proportionalRewind(
            oldTurns.toDoubleOrZero(), oldVoltage.toDoubleOrZero(), newVoltage.toDoubleOrZero(),
            oldCurrent.toDoubleOrZero(), oldWireDia.toDoubleOrZero()
        )
    }

    Text(
        "Use this when you have the original (burnt) winding's data plate turns/coil and want to rewind for a different supply voltage on the same core.",
        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
    )
    Spacer(Modifier.height(8.dp))

    NumberField("Old Turns per Coil", oldTurns) { oldTurns = it }
    NumberField("Old Voltage", oldVoltage, "V") { oldVoltage = it }
    NumberField("New Voltage", newVoltage, "V") { newVoltage = it }
    NumberField("Old Current", oldCurrent, "A") { oldCurrent = it }
    NumberField("Old Wire Diameter", oldWireDia, "mm") { oldWireDia = it }

    ResultCard(
        "New Winding Data",
        listOf(
            "New Turns per Coil" to fmt(result.newTurnsPerCoil, 1),
            "New Estimated Current" to "${fmt(result.newCurrentA)} A",
            "New Wire Cross-Section" to "${fmt(result.newWireCsaMm2, 4)} mm²",
            "New Wire Diameter" to "${fmt(result.newWireDiameterMm, 3)} mm"
        )
    )
}

@Composable
private fun FluxDesignSection() {
    var phaseVoltage by remember { mutableStateOf("230") }
    var freq by remember { mutableStateOf("50") }
    var bore by remember { mutableStateOf("120") }
    var stackLength by remember { mutableStateOf("100") }
    var poles by remember { mutableStateOf("4") }
    var fluxDensity by remember { mutableStateOf("0.65") }
    var kw by remember { mutableStateOf("0.955") }
    var coilsPerPhase by remember { mutableStateOf("6") }
    var paths by remember { mutableStateOf("1") }

    val result = remember(phaseVoltage, freq, bore, stackLength, poles, fluxDensity, kw, coilsPerPhase, paths) {
        Calculators.fluxBasedTurns(
            phaseVoltage.toDoubleOrZero(), freq.toDoubleOrZero(),
            bore.toDoubleOrZero(), stackLength.toDoubleOrZero(),
            poles.toIntOrNull()?.coerceAtLeast(2) ?: 4,
            fluxDensity.toDoubleOrZero(), kw.toDoubleOrZero(),
            coilsPerPhase.toIntOrNull()?.coerceAtLeast(1) ?: 6,
            paths.toIntOrNull()?.coerceAtLeast(1) ?: 1
        )
    }

    Text(
        "Use this to design turns from scratch, e.g. for a re-core or when no original winding data survives. Typical flux density for stator cores is 0.55–0.75 T; use the Winding Scheme screen's Kw for accuracy.",
        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
    )
    Spacer(Modifier.height(8.dp))

    NumberField("Phase Voltage", phaseVoltage, "V") { phaseVoltage = it }
    NumberField("Frequency", freq, "Hz") { freq = it }
    NumberField("Stator Bore Diameter", bore, "mm") { bore = it }
    NumberField("Core Stack Length", stackLength, "mm") { stackLength = it }
    NumberField("Number of Poles", poles) { poles = it }
    NumberField("Flux Density (Bm)", fluxDensity, "T") { fluxDensity = it }
    NumberField("Winding Factor (Kw)", kw) { kw = it }
    NumberField("Coils per Phase", coilsPerPhase) { coilsPerPhase = it }
    NumberField("Parallel Paths", paths) { paths = it }

    ResultCard(
        "Design Results",
        listOf(
            "Flux per Pole" to "${fmt(result.fluxPerPoleWb * 1000, 3)} mWb",
            "Turns per Phase" to fmt(result.turnsPerPhase, 1),
            "Turns per Coil" to fmt(result.turnsPerCoil, 1)
        )
    )
}
