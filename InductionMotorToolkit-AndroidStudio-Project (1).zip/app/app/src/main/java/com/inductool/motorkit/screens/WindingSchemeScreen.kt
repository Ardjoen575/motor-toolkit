package com.inductool.motorkit.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.inductool.motorkit.Calculators

@Composable
fun WindingSchemeScreen() {
    var slots by remember { mutableStateOf("36") }
    var poles by remember { mutableStateOf("4") }
    var chordedOverride by remember { mutableStateOf("") }

    val slotsN = slots.toIntOrNull()?.coerceAtLeast(3) ?: 36
    val polesN = poles.toIntOrNull()?.coerceAtLeast(2) ?: 4
    val override = chordedOverride.toIntOrNull()

    val result = remember(slotsN, polesN, override) {
        Calculators.windingScheme(slotsN, polesN, 3, override)
    }

    ScreenScaffold(
        title = "Winding Scheme",
        helpText = "Double-layer, 3-phase, 60° phase-belt winding layout: pole pitch, coil pitch, winding factor, and slot-by-slot phase table."
    ) {
        NumberField("Total Stator Slots", slots) { slots = it }
        NumberField("Number of Poles", poles) { poles = it }
        NumberField("Coil Pitch Override (slots, optional)", chordedOverride) { chordedOverride = it }

        if (!result.isIntegerSlot) {
            Text(
                "Note: slots-per-pole-per-phase (q) is not a whole number — this is a fractional-slot winding. The table below is an approximation; fractional windings need specialist design.",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        ResultCard(
            "Layout Results",
            listOf(
                "Slots per Pole" to fmt(result.slotsPerPole, 2),
                "Slots per Pole per Phase (q)" to fmt(result.slotsPerPolePerPhase, 3),
                "Electrical Degrees / Slot" to "${fmt(result.electricalDegreesPerSlot)} °",
                "Full Pitch" to "${result.fullPitchSlots} slots",
                "Recommended Coil Pitch" to "${result.recommendedChordedPitchSlots} slots",
                "Pitch Factor (Kp)" to fmt(result.pitchFactorKp, 4),
                "Distribution Factor (Kd)" to fmt(result.distributionFactorKd, 4),
                "Winding Factor (Kw)" to fmt(result.windingFactorKw, 4)
            )
        )

        Text(
            "Slot → Phase Table",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(6),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 400.dp)
        ) {
            items(result.slotTable) { slot ->
                val color = when (slot.phase) {
                    "A" -> Color(0xFFE53935)
                    "B" -> Color(0xFF43A047)
                    else -> Color(0xFF1E88E5)
                }
                Card(
                    modifier = Modifier.padding(2.dp),
                    colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f))
                ) {
                    Column(
                        Modifier.padding(6.dp),
                        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                    ) {
                        Text("S${slot.slotIndex + 1}", style = MaterialTheme.typography.labelSmall)
                        Text(
                            "${slot.phase}${if (slot.direction > 0) "+" else "-"}",
                            fontWeight = FontWeight.Bold,
                            color = color
                        )
                    }
                }
            }
        }
    }
}
