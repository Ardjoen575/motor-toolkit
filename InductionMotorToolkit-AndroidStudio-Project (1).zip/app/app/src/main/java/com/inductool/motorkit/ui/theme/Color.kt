package com.inductool.motorkit.ui.theme

import androidx.compose.ui.graphics.Color

val MotorBlue = Color(0xFF0D47A1)
val MotorBlueLight = Color(0xFF5472D3)
val MotorAmber = Color(0xFFFFA000)
val SurfaceLight = Color(0xFFF7F9FC)
val SurfaceDark = Color(0xFF10151C)
